n = int(input("enter no: "))

if n > 21:
    if n > 100:
        print('too old')
    else:
        print('less than 100')
else:
    print('too young')
