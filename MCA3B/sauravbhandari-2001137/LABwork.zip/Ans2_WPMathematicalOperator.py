value1 = 2
value2 = 3

ans = value1 + value2
print(ans)
