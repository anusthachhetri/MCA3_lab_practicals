
str = [10, 1, 15, 8, 3]
print(sorted(str))  # with sorting
print(str)  # without sorting

# print index of 8
index = str.index(8)
print(index)

# print 80 is not in list
index = str.index(80)
print(index)
