num = int(input("enter no: "))

if num >= 100:
    print("greater than 100")
else:
    print("less than 100")
