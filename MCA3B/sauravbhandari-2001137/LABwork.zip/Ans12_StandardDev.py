import statistics

data = [11, 20, 3, 24, 15]
print("Standard Deviation of sample is %s " % (statistics.stdev(data)))
# Standard Deviation of sample is 8.142481194328914

data2 = [9, 1, 2, 5]
print("Standard Deviation of sample is %s " % (statistics.stdev(data2)))
# Standard Deviation of sample is 3.593976442141304
