print("Programs on Basics of Python")

# output
# Programs on Basics of Python
