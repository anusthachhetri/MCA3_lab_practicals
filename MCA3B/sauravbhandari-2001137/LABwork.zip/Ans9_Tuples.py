# Python Tuple

tuple1 = [1, 2, 3, 4, 5, 6, 7, 8]
print(tuple1)

tuple2 = [1, 2, ("user"), 3, 4, 5, 6, 7, 8]
print(tuple2)
print(tuple2[2][2])  # print  users's => e
