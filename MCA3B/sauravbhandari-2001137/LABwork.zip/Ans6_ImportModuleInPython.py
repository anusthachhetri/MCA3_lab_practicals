# Import module in Python
from math import *
import math

print(math.pi)
print(math.sin(math.pi/2))

print(factorial(6))
